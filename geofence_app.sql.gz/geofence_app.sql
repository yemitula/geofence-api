-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';


INSERT INTO `location` (`loc_id`, `loc_name`, `loc_lat`, `loc_long`, `loc_address`, `loc_radius`) VALUES
(1,	'Home Address',	'98765455',	'45466656',	'1, Kosofe Street, Abaaranje, Ikotun.',	5353676),
(2,	'Office',	'78455785',	'745675677',	'1, , aliyu strt',	5457890),
(3,	'Tula\'s Home Ojodu',	'6.6470081',	'3.3575377',	'27, Dipo Abe Street, Ojodu, Lagos',	10);


INSERT INTO `staff` (`stf_id`, `stf_name`, `stf_email`, `stf_password`, `stf_no`, `stf_safety_code`, `stf_location_id`) VALUES
(1,	'Ada Dundun',	'ada@dundun.com',	'fufu12',	'001',	'54ygg3tyre6t',	1),
(2,	'Solid AC',	'solid@ac.com',	'mada33',	'002',	'74yrygyt',	1),
(3,	'Ruth Obidike',	'ruth@yahoo.com',	'rut123',	'76',	'3109372',	2),
(4,	'Ruth Obidike',	'ruth2@yahoo.com',	'rut123',	'45',	'5990512',	1),
(5,	'Abike Jessy',	'abi@jesi.org',	'jessy12',	'34',	'8553345',	2),
(6,	'Yemi Adetula',	'yemitula@gmail.com',	'yemi123',	'T0001',	'8677650',	3),
(7,	'Ebun Olotu',	'ebun@tulabyte.net',	'ebun123',	'EBUN',	'2391833',	1);

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_address`, `user_password`) VALUES
(1,	'Ruth Chisom',	'ruth@tulabyte.net',	'64 New Ogorode Road, Sapele, Delta State, Nigeria',	'mom.dad'),
(2,	'Yemi Tula',	'yemitula@gmail.com',	'27, Dipo Abe Street, Ojodu',	'yemi123');

-- 2020-08-11 09:18:48
