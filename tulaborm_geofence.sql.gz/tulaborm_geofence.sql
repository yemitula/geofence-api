-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `fence_exit` (
  `fex_id` int(11) NOT NULL AUTO_INCREMENT,
  `fex_staff_id` int(11) NOT NULL,
  `fex_location_id` int(11) NOT NULL,
  `fex_lat` int(50) NOT NULL,
  `fex_long` int(50) NOT NULL,
  `fex_time_exited` datetime NOT NULL,
  `fex_code_expected` varchar(100) NOT NULL,
  `fex_code_supplied` varchar(100) NOT NULL,
  `fex_is_safe` int(1) NOT NULL,
  `fex_time_returned` datetime NOT NULL,
  PRIMARY KEY (`fex_id`),
  KEY `fex_staff_id` (`fex_staff_id`),
  KEY `fex_location_id` (`fex_location_id`),
  CONSTRAINT `fence_exit_ibfk_1` FOREIGN KEY (`fex_staff_id`) REFERENCES `staff` (`stf_id`) ON DELETE CASCADE,
  CONSTRAINT `fence_exit_ibfk_2` FOREIGN KEY (`fex_location_id`) REFERENCES `location` (`loc_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `location` (
  `loc_id` int(11) NOT NULL AUTO_INCREMENT,
  `loc_name` varchar(100) NOT NULL,
  `loc_lat` varchar(20) NOT NULL,
  `loc_long` varchar(20) NOT NULL,
  `loc_address` varchar(100) NOT NULL,
  `loc_radius` int(50) NOT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `location` (`loc_id`, `loc_name`, `loc_lat`, `loc_long`, `loc_address`, `loc_radius`) VALUES
(1,	'Home Address',	'98765455',	'45466656',	'1, Kosofe Street, Abaaranje, Ikotun.',	5353676),
(2,	'Office',	'78455785',	'745675677',	'1, , aliyu strt',	5457890),
(3,	'Tula\'s Home Ojodu',	'6.6470081',	'3.3575377',	'27, Dipo Abe Street, Ojodu, Lagos',	10);

CREATE TABLE `movement` (
  `mov_id` int(11) NOT NULL,
  `mov_exit_id` int(11) NOT NULL,
  `mov_lat` int(50) NOT NULL,
  `mov_long` int(50) NOT NULL,
  `mov_time` datetime NOT NULL,
  KEY `mov_exit_id` (`mov_exit_id`),
  CONSTRAINT `movement_ibfk_1` FOREIGN KEY (`mov_exit_id`) REFERENCES `fence_exit` (`fex_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `staff` (
  `stf_id` int(11) NOT NULL AUTO_INCREMENT,
  `stf_name` varchar(100) NOT NULL,
  `stf_email` varchar(100) NOT NULL,
  `stf_password` varchar(100) NOT NULL,
  `stf_no` varchar(100) NOT NULL,
  `stf_safety_code` varchar(100) NOT NULL,
  `stf_location_id` int(11) NOT NULL,
  `stf_device_id` varchar(100) DEFAULT NULL,
  `stf_time_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`stf_id`),
  KEY `stf_location_id` (`stf_location_id`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`stf_location_id`) REFERENCES `location` (`loc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staff` (`stf_id`, `stf_name`, `stf_email`, `stf_password`, `stf_no`, `stf_safety_code`, `stf_location_id`, `stf_device_id`, `stf_time_updated`) VALUES
(1,	'Ada Dundun',	'ada@dundun.com',	'fufu12',	'001',	'54ygg3tyre6t',	1,	NULL,	NULL),
(2,	'Solid AC',	'solid@ac.com',	'mada33',	'002',	'74yrygyt',	1,	NULL,	NULL),
(3,	'Ruth Obidike',	'ruth@yahoo.com',	'rut123',	'76',	'3109372',	2,	NULL,	NULL),
(4,	'Ruth Obidike',	'ruth2@yahoo.com',	'rut123',	'45',	'5990512',	1,	NULL,	NULL),
(5,	'Abike Jessy',	'abi@jesi.org',	'jessy12',	'34',	'8553345',	2,	NULL,	NULL),
(6,	'Yemi Adetula',	'yemitula@gmail.com',	'yemi123',	'T0001',	'8677650',	3,	NULL,	'2020-08-19 23:04:34'),
(7,	'Ebun Olotu',	'ebun@tulabyte.net',	'ebun123',	'EBUN',	'2391833',	1,	NULL,	NULL);

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_address` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_address`, `user_password`) VALUES
(1,	'Ruth Chisom',	'ruth@tulabyte.net',	'64 New Ogorode Road, Sapele, Delta State, Nigeria',	'mom.dad'),
(2,	'Yemi Tula',	'yemitula@gmail.com',	'27, Dipo Abe Street, Ojodu',	'yemi123');

-- 2020-09-07 06:39:07
